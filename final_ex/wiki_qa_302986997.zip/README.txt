302986997 - ronyjacobson@gmail.com - Rony Jacobson Levi
201316858 - nath.ozeri@gmail.com - Nathanel ozeri

Run wiki_qa with Python2.7